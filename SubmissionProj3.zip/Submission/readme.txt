Project 3 - Socket Communication
Matthew Synborski
Submission 1
matthewsynborski@gmail.com
Spring 2013, CSE-687

Usage:
1. 	To verify the test package, 
	a. 	Run the compile.bat script in the test folder.
	b. 	Run the run.bat script in the test folder.

2. 	To verify the display package, 
	a. 	Run the compile.bat script in the display folder.
	b. 	Run the run.bat script in the display folder.

See Requirements Trace Matrix for verification guidance:


